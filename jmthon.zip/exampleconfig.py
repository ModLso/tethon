from sample_config import Config


class Development(Config):
    #هنا ضع الكودات الخاصه بك امسح الكلام العربي وضعهن
    APP_ID = 6
    API_HASH = "هنا الايبي هاش"
    ALIVE_NAME = "اسم حسابك"
    DB_URI = "رابط تخزينك"
    STRING_SESSION = "كود تيرمكس"
    TG_BOT_TOKEN = "توكن بوتك"
    TG_BOT_USERNAME = "معرف بوتك بدون @"
    PRIVATE_GROUP_BOT_API_ID = -100
    COMMAND_HAND_LER = "."
    SUDO_USERS = []
    SUDO_COMMAND_HAND_LER = "،"
    TZ = "Asia/Baghdad"
#t.me/jmthon
